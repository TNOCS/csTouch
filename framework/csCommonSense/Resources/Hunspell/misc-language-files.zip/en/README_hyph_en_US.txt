Hyphenation dictionary
----------------------

Language: English (en US).
Origin:   Based on the TeX hyphenation tables
License:  GNU LGPL license.
Author:   conversion author is Peter Novodvorsky <nidd@altlinux.ru>

This hyphenation dictionary is based on syllable matching patterns and
should be usable under other variations of English

HYPH en US hyph_en_US
HYPH en CA hyph_en_CA
HYPH en GB hyph_en_GB
HYPH en AU hyph_en_AU



