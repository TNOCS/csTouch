Hyphenation dictionary
----------------------

Language: German (de DE).
Origin:   Based on the TeX hyphenation tables
License:  GNU LGPL license.
Author:   conversion author is Marco Huggenberger<marco@by-night.ch>

Please note, this dictionary is based on syllable matching patterns
and thus should be suitable under other variations of German

HYPH de DE hyph_de_DE
HYPH de CH hyph_de_CH


