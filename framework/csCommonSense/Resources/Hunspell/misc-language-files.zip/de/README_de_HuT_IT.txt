Informationen zu der de_HuT_IT.dic

Aufgabe:
Deutsches Erg�nzungsw�rterbuch f�r die Informationstechnik.

Version 1.2
Die aktuelle Version finden Sie im Katalog unter http://www.it-know-how.net.

Installation:
Um das W�rterbuch von Hand zu installieren, kopieren Sie �de_HuT_IT.dic� und �README_de_HuT_IT.txt� in das Verzeichnis, in dem die Datei �dictionary.lst� liegt. Das kann das Verzeichnis �[OOo]/share/dic/ooo/� oder das Verzeichnis �[OOo]/user/wordbook/� sein. M�glicherweise liegt in beiden Verzeichnissen eine �dictionary.lst�. Nehmen Sie dann das Verzeichnis, in dem auch die �de_DE.dic� liegt.

Anschliessend f�gen sie die folgende Zeile in der �dictionary.lst� ein und starten OpenOffice.org und einen eventuell laufenden Schnellstarter neu:
DICT de DE de_HuT_IT

Lizenz:
LGPL

Bei Fragen:
Handel und Technik Verlag
Wolfgang Henderkes
Robert-Bosch-Str. 2
59439 Holzwickede
Telefon: 0 23 01 / 91 74 03
Telefax: 0 23 01 / 91 71 00
eMail: Wolfgang.Henderkes@IT-Know-how.NET
http://www.IT-Know-how.NET